import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
LOCAL_CATALOG = os.path.join(ADDON_PATH, "catalogo.json")
CACHE_CATALOG = os.path.join(PROFILE_PATH, "catalogo_cache.json")


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo(forcar_atualizacao=False):
    url_remota = ADDON.getSetting("url_catalogo").strip()
    usar_cache = ADDON.getSettingBool("usar_cache")

    if url_remota:
        try:
            req = urllib.request.Request(
                url_remota,
                headers={"User-Agent": "Mozilla/5.0 (Kodi CineTelona)"}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                conteudo = resp.read().decode("utf-8")
                dados = json.loads(conteudo)

                if not os.path.exists(PROFILE_PATH):
                    os.makedirs(PROFILE_PATH, exist_ok=True)
                with open(CACHE_CATALOG, "w", encoding="utf-8") as f:
                    f.write(conteudo)

                if forcar_atualizacao:
                    xbmcgui.Dialog().notification(
                        "Cine Telona",
                        "Catálogo remoto atualizado com sucesso!",
                        xbmcgui.NOTIFICATION_INFO,
                        3000
                    )
                return dados
        except Exception as e:
            xbmc.log(f"[CineTelona] Erro ao baixar catálogo remoto: {e}", xbmc.LOGERROR)
            if forcar_atualizacao:
                xbmcgui.Dialog().notification(
                    "Cine Telona",
                    "Falha ao baixar URL remota. Verifique o link.",
                    xbmcgui.NOTIFICATION_ERROR,
                    4000
                )
            if usar_cache and os.path.exists(CACHE_CATALOG):
                with open(CACHE_CATALOG, "r", encoding="utf-8") as f:
                    return json.load(f)

    with open(LOCAL_CATALOG, "r", encoding="utf-8") as f:
        return json.load(f)


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    itens = [
        ("Filmes", get_url(action="listar_filmes"), True),
        ("Séries", get_url(action="listar_series"), True),
        ("Atualizar Catálogo Remoto", get_url(action="atualizar"), False),
        ("Configurar URL do Catálogo", get_url(action="configurar"), False),
    ]

    for titulo, url, is_folder in itens:
        item = xbmcgui.ListItem(label=titulo)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")
    dados = carregar_catalogo()

    for filme in dados.get("filmes", []):
        titulo = filme.get("titulo", "Sem título")
        ano = filme.get("ano", 0)
        label = f"{titulo} ({ano})" if ano else titulo

        item = xbmcgui.ListItem(label=label)
        item.setInfo("video", {
            "title": titulo,
            "year": ano,
            "plot": filme.get("sinopse", ""),
            "mediatype": "movie"
        })
        item.setArt({
            "poster": filme.get("capa", ""),
            "thumb": filme.get("capa", ""),
            "fanart": filme.get("fundo", "")
        })
        item.setProperty("IsPlayable", "true")

        url = get_url(action="play", link=filme.get("magnet", ""))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")
    dados = carregar_catalogo()

    for idx, serie in enumerate(dados.get("series", [])):
        titulo = serie.get("titulo", "Sem título")
        item = xbmcgui.ListItem(label=titulo)
        item.setInfo("video", {
            "title": titulo,
            "year": serie.get("ano", 0),
            "plot": serie.get("sinopse", ""),
            "mediatype": "tvshow"
        })
        item.setArt({
            "poster": serie.get("capa", ""),
            "thumb": serie.get("capa", ""),
            "fanart": serie.get("fundo", "")
        })

        url = get_url(action="listar_temporadas", serie_idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_temporadas(serie_idx):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if serie_idx >= len(series):
        return

    serie = series[serie_idx]
    xbmcplugin.setPluginCategory(HANDLE, serie.get("titulo", "Temporadas"))
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp in sorted(serie.get("temporadas", {}).keys(), key=lambda x: int(x) if x.isdigit() else x):
        item = xbmcgui.ListItem(label=f"Temporada {temp}")
        item.setArt({
            "poster": serie.get("capa", ""),
            "fanart": serie.get("fundo", "")
        })
        url = get_url(action="listar_episodios", serie_idx=serie_idx, temporada=temp)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(serie_idx, temporada):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if serie_idx >= len(series):
        return

    serie = series[serie_idx]
    episodios = serie.get("temporadas", {}).get(temporada, [])
    xbmcplugin.setPluginCategory(HANDLE, f"{serie.get('titulo')} - T{temporada}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for ep in episodios:
        num = ep.get("episodio", 1)
        titulo = ep.get("titulo", f"Episódio {num}")
        label = f"{int(temporada):02d}x{int(num):02d} - {titulo}"

        item = xbmcgui.ListItem(label=label)
        item.setInfo("video", {
            "title": titulo,
            "season": int(temporada) if str(temporada).isdigit() else 1,
            "episode": int(num) if str(num).isdigit() else 1,
            "plot": ep.get("sinopse", ""),
            "mediatype": "episode"
        })
        item.setArt({
            "thumb": ep.get("capa", serie.get("capa", "")),
            "fanart": serie.get("fundo", "")
        })
        item.setProperty("IsPlayable", "true")

        url = get_url(action="play", link=ep.get("magnet", ""))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(link):
    if not link:
        xbmcgui.Dialog().notification("Cine Telona", "Link vazio!", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if link.startswith("magnet:"):
        encoded = urllib.parse.quote_plus(link)
        destino = f"plugin://plugin.video.elementum/play?uri={encoded}"
    else:
        destino = link

    item = xbmcgui.ListItem(path=destino)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "listar_filmes":
        listar_filmes()
    elif action == "listar_series":
        listar_series()
    elif action == "listar_temporadas":
        listar_temporadas(int(params.get("serie_idx", 0)))
    elif action == "listar_episodios":
        listar_episodios(int(params.get("serie_idx", 0)), params.get("temporada", "1"))
    elif action == "play":
        reproduzir(params.get("link", ""))
    elif action == "atualizar":
        carregar_catalogo(forcar_atualizacao=True)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "configurar":
        ADDON.openSettings()
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[1][1:] if len(sys.argv) > 2 else "")
