import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CATALOGO_LOCAL = os.path.join(ADDON_PATH, "catalogo.json")
CATALOGO_CACHE = os.path.join(PROFILE_PATH, "catalogo_cache.json")

URL_CATALOGO_FIXA = "https://nogueira01.github.io/cinetelona/catalogo.json"


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    if not os.path.exists(PROFILE_PATH):
        os.makedirs(PROFILE_PATH, exist_ok=True)

    try:
        req = urllib.request.Request(
            URL_CATALOGO_FIXA,
            headers={"User-Agent": "Mozilla/5.0 (Kodi CineTelona)"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            dados = json.loads(raw)
            with open(CATALOGO_CACHE, "w", encoding="utf-8") as f:
                json.dump(dados, f, ensure_ascii=False, indent=2)
            return dados
    except Exception:
        if os.path.exists(CATALOGO_CACHE):
            try:
                with open(CATALOGO_CACHE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        if os.path.exists(CATALOGO_LOCAL):
            with open(CATALOGO_LOCAL, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"filmes": [], "series": []}


def aplicar_metadados(item, titulo, sinopse="", ano=0, capa="", fundo="", mediatype="movie", serie="", temporada=0, episodio=0):
    info = {
        "title": titulo,
        "plot": sinopse,
        "plotoutline": sinopse,
        "mediatype": mediatype,
    }
    if ano:
        try:
            info["year"] = int(ano)
        except Exception:
            pass
    if serie:
        info["tvshowtitle"] = serie
    if temporada:
        try:
            info["season"] = int(temporada)
        except Exception:
            pass
    if episodio:
        try:
            info["episode"] = int(episodio)
        except Exception:
            pass

    item.setInfo("video", info)

    art = {}
    if capa:
        art["thumb"] = capa
        art["poster"] = capa
        art["icon"] = capa
    if fundo:
        art["fanart"] = fundo
    if art:
        item.setArt(art)


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    itens = [
        ("Filmes", "filmes", "Catálogo de filmes disponíveis."),
        ("Séries", "series", "Catálogo de séries disponíveis."),
    ]
    for rotulo, acao, desc in itens:
        item = xbmcgui.ListItem(label=rotulo)
        item.setInfo("video", {"title": rotulo, "plot": desc})
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=get_url(action=acao),
            listitem=item,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")
    dados = carregar_catalogo()

    for idx, filme in enumerate(dados.get("filmes", [])):
        titulo = filme.get("titulo", "Sem título")
        ano = filme.get("ano", 0)
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa", "")
        fundo = filme.get("fundo", "")
        opcoes = filme.get("opcoes", [])
        magnet_direto = filme.get("magnet", "")

        rotulo = f"{titulo} ({ano})" if ano else titulo
        item = xbmcgui.ListItem(label=rotulo)
        aplicar_metadados(item, titulo, sinopse, ano, capa, fundo, "movie")

        if opcoes:
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
        elif magnet_direto:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet_direto,
                titulo=titulo,
                sinopse=sinopse,
                ano=ano,
                capa=capa,
                fundo=fundo,
                mediatype="movie",
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_filme(idx):
    dados = carregar_catalogo()
    filmes = dados.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Sem título")
    ano = filme.get("ano", 0)
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa", "")
    fundo = filme.get("fundo", "")

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for opc in filme.get("opcoes", []):
        qualidade = opc.get("qualidade", "Padrão")
        magnet = opc.get("magnet", "")
        if not magnet:
            continue

        rotulo = f"{titulo} - [{qualidade}]"
        item = xbmcgui.ListItem(label=rotulo)
        aplicar_metadados(item, titulo, sinopse, ano, capa, fundo, "movie")
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            titulo=titulo,
            sinopse=sinopse,
            ano=ano,
            capa=capa,
            fundo=fundo,
            mediatype="movie",
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")
    dados = carregar_catalogo()

    for idx, serie in enumerate(dados.get("series", [])):
        titulo = serie.get("titulo", "Série sem título")
        ano = serie.get("ano", 0)
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa", "")
        fundo = serie.get("fundo", "")

        rotulo = f"{titulo} ({ano})" if ano else titulo
        item = xbmcgui.ListItem(label=rotulo)
        aplicar_metadados(item, titulo, sinopse, ano, capa, fundo, "tvshow", serie=titulo)

        url = get_url(action="temporadas", idx=idx)
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_temporadas(idx):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa", "")
    fundo = serie.get("fundo", "")

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    temporadas = serie.get("temporadas", {})
    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else str(x)):
        rotulo = f"Temporada {temp_num}"
        item = xbmcgui.ListItem(label=rotulo)
        aplicar_metadados(item, rotulo, sinopse, ano, capa, fundo, "season", serie=titulo, temporada=temp_num)
        url = get_url(action="episodios", idx=idx, temp=temp_num)
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(idx, temp_num):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    nome_serie = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa_serie = serie.get("capa", "")
    fundo_serie = serie.get("fundo", "")

    xbmcplugin.setPluginCategory(HANDLE, f"{nome_serie} - Temporada {temp_num}")
    xbmcplugin.setContent(HANDLE, "episodes")

    episodios = serie.get("temporadas", {}).get(str(temp_num), [])
    for ep_idx, ep in enumerate(episodios):
        num_ep = ep.get("episodio", ep_idx + 1)
        tit_ep = ep.get("titulo", f"Episódio {num_ep}")
        sin_ep = ep.get("sinopse", serie.get("sinopse", ""))
        capa_ep = ep.get("capa", capa_serie)
        fundo_ep = ep.get("fundo", fundo_serie)
        opcoes = ep.get("opcoes", [])
        magnet_direto = ep.get("magnet", "")

        rotulo = f"{int(temp_num):02d}x{int(num_ep):02d} - {tit_ep}" if str(temp_num).isdigit() and str(num_ep).isdigit() else f"{num_ep} - {tit_ep}"
        item = xbmcgui.ListItem(label=rotulo)
        aplicar_metadados(
            item,
            tit_ep,
            sin_ep,
            ano,
            capa_ep,
            fundo_ep,
            "episode",
            serie=nome_serie,
            temporada=temp_num,
            episodio=num_ep,
        )

        if opcoes:
            url = get_url(action="opcoes_episodio", idx=idx, temp=temp_num, ep_idx=ep_idx)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
        elif magnet_direto:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet_direto,
                titulo=tit_ep,
                sinopse=sin_ep,
                ano=ano,
                capa=capa_ep,
                fundo=fundo_ep,
                mediatype="episode",
                serie=nome_serie,
                temporada=temp_num,
                episodio=num_ep,
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_episodio(idx, temp_num, ep_idx):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    nome_serie = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa_serie = serie.get("capa", "")
    fundo_serie = serie.get("fundo", "")

    episodios = serie.get("temporadas", {}).get(str(temp_num), [])
    if ep_idx < 0 or ep_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[ep_idx]
    num_ep = ep.get("episodio", ep_idx + 1)
    tit_ep = ep.get("titulo", f"Episódio {num_ep}")
    sin_ep = ep.get("sinopse", serie.get("sinopse", ""))
    capa_ep = ep.get("capa", capa_serie)
    fundo_ep = ep.get("fundo", fundo_serie)

    xbmcplugin.setPluginCategory(HANDLE, tit_ep)
    xbmcplugin.setContent(HANDLE, "episodes")

    for opc in ep.get("opcoes", []):
        qualidade = opc.get("qualidade", "Padrão")
        magnet = opc.get("magnet", "")
        if not magnet:
            continue

        rotulo = f"{tit_ep} - [{qualidade}]"
        item = xbmcgui.ListItem(label=rotulo)
        aplicar_metadados(
            item,
            tit_ep,
            sin_ep,
            ano,
            capa_ep,
            fundo_ep,
            "episode",
            serie=nome_serie,
            temporada=temp_num,
            episodio=num_ep,
        )
        item.setProperty("IsPlayable", "true")
        url = get_url(
            action="play",
            magnet=magnet,
            titulo=tit_ep,
            sinopse=sin_ep,
            ano=ano,
            capa=capa_ep,
            fundo=fundo_ep,
            mediatype="episode",
            serie=nome_serie,
            temporada=temp_num,
            episodio=num_ep,
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    titulo = params.get("titulo", "Cine Telona")
    sinopse = params.get("sinopse", "")
    ano = params.get("ano", 0)
    capa = params.get("capa", "")
    fundo = params.get("fundo", "")
    mediatype = params.get("mediatype", "movie")
    serie = params.get("serie", "")
    temporada = params.get("temporada", 0)
    episodio = params.get("episodio", 0)

    if not magnet:
        xbmcgui.Dialog().notification("Cine Telona", "Link inválido.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "O add-on Elementum não está instalado. Instale o Elementum para reproduzir links torrent.",
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote(magnet)}"
    else:
        play_path = magnet

    item = xbmcgui.ListItem(label=titulo, path=play_path)
    aplicar_metadados(item, titulo, sinopse, ano, capa, fundo, mediatype, serie, temporada, episodio)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", -1)))
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("idx", -1)), params.get("temp", "1"))
    elif action == "opcoes_episodio":
        listar_opcoes_episodio(int(params.get("idx", -1)), params.get("temp", "1"), int(params.get("ep_idx", -1)))
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
