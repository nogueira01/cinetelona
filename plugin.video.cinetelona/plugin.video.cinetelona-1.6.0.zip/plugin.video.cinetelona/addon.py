import sys
import os
import json
import ssl
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
ICON_DEFAULT = os.path.join(ADDON_PATH, "icon.png")
FANART_DEFAULT = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")
ICON_BUSCA = os.path.join(ADDON_PATH, "resources", "icon_busca.png")

URL_CATALOGO = "https://nogueira01.github.io/cinetelona/catalogo.json"


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    try:
        ctx = ssl._create_unverified_context()
        req = urllib.request.Request(URL_CATALOGO, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            raw = resp.read().decode("utf-8")
            data = json.loads(raw)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    local_file = os.path.join(ADDON_PATH, "catalogo.json")
    if os.path.exists(local_file):
        try:
            with open(local_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"filmes": [], "series": []}


def aplicar_painel_grande():
    xbmc.executebuiltin("Container.SetViewMode(51)")


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "files")
    cat = carregar_catalogo()
    total_filmes = len(cat.get("filmes", []))
    total_series = len(cat.get("series", []))

    # Mensagem de boas-vindas no topo
    item_bv = xbmcgui.ListItem(label="[B][COLOR FF00E5FF]★ Bem-vindo ao Cine Telona ★[/COLOR][/B]")
    item_bv.setArt({"icon": ICON_DEFAULT, "thumb": ICON_DEFAULT, "fanart": FANART_DEFAULT})
    item_bv.setInfo("video", {"title": "Bem-vindo ao Cine Telona", "plot": "Escolha Filmes ou Séries abaixo para explorar o catálogo."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="boas_vindas"), listitem=item_bv, isFolder=False)

    # Menu Filmes
    item_f = xbmcgui.ListItem(label=f"[B][COLOR FF00E5FF]FILMES[/COLOR][/B]  [COLOR FFAAAAAA]({total_filmes} títulos)[/COLOR]")
    item_f.setArt({"icon": ICON_FILMES, "thumb": ICON_FILMES, "poster": ICON_FILMES, "fanart": FANART_DEFAULT})
    item_f.setInfo("video", {"title": "Filmes", "plot": "Catálogo completo de filmes disponíveis."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="filmes"), listitem=item_f, isFolder=True)

    # Menu Séries
    item_s = xbmcgui.ListItem(label=f"[B][COLOR FFB565FF]SÉRIES[/COLOR][/B]  [COLOR FFAAAAAA]({total_series} títulos)[/COLOR]")
    item_s.setArt({"icon": ICON_SERIES, "thumb": ICON_SERIES, "poster": ICON_SERIES, "fanart": FANART_DEFAULT})
    item_s.setInfo("video", {"title": "Séries", "plot": "Catálogo completo de séries organizadas por temporadas."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="series"), listitem=item_s, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def adicionar_item_filme(idx, filme):
    titulo = filme.get("titulo", "Sem Título")
    ano = filme.get("ano", "")
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_DEFAULT
    fundo = filme.get("fundo") or FANART_DEFAULT
    label = f"[B]{titulo}[/B] ({ano})" if ano else f"[B]{titulo}[/B]"

    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
    info = {"title": titulo, "plot": sinopse, "mediatype": "movie"}
    if str(ano).isdigit():
        info["year"] = int(ano)
    item.setInfo("video", info)

    opcoes = filme.get("opcoes", [])
    if opcoes:
        url = get_url(action="filme_opcoes", idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
    else:
        magnet = filme.get("magnet", "")
        item.setProperty("IsPlayable", "true")
        url = get_url(
            action="play",
            magnet=magnet,
            titulo=titulo,
            ano=str(ano),
            sinopse=sinopse,
            capa=capa,
            fundo=fundo,
            mediatype="movie",
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)


def listar_filmes(filtro=""):
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")
    cat = carregar_catalogo()
    filmes = cat.get("filmes", [])

    # Barra de busca no topo de Filmes
    lbl_busca = "[B][COLOR FF00E5FF]🔍 Buscar Filme...[/COLOR][/B]" if not filtro else f"[B][COLOR FF00E5FF]🔍 Filtro: '{filtro}' (Limpar / Nova Busca)[/COLOR][/B]"
    item_b = xbmcgui.ListItem(label=lbl_busca)
    item_b.setArt({"icon": ICON_BUSCA, "thumb": ICON_BUSCA, "poster": ICON_BUSCA, "fanart": FANART_DEFAULT})
    item_b.setInfo("video", {"title": "Buscar Filme", "plot": "Digite o nome do filme para pesquisar."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="buscar_filmes"), listitem=item_b, isFolder=True)

    termo = filtro.strip().lower()
    for idx, filme in enumerate(filmes):
        if termo and termo not in filme.get("titulo", "").lower():
            continue
        adicionar_item_filme(idx, filme)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def buscar_filmes():
    kb = xbmc.Keyboard("", "Buscar Filme no Cine Telona")
    kb.doModal()
    if kb.isConfirmed():
        texto = kb.getText()
        listar_filmes(filtro=texto)
    else:
        listar_filmes()


def listar_opcoes_filme(idx):
    cat = carregar_catalogo()
    filmes = cat.get("filmes", [])
    if idx >= len(filmes):
        return
    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", "")
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_DEFAULT
    fundo = filme.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for op in filme.get("opcoes", []):
        qual = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        q_low = qual.lower()
        if "4k" in q_low or "2160" in q_low:
            badge = f"[COLOR FFFFD700]★ {qual}[/COLOR]"
        elif "full" in q_low:
            badge = f"[COLOR FFB565FF]◆ {qual}[/COLOR]"
        else:
            badge = f"[COLOR FF00E5FF]● {qual}[/COLOR]"

        item = xbmcgui.ListItem(label=f"[B]{titulo}[/B]  -  {badge}")
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        info = {"title": f"{titulo} ({qual})", "plot": sinopse, "mediatype": "movie"}
        if str(ano).isdigit():
            info["year"] = int(ano)
        item.setInfo("video", info)
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            titulo=titulo,
            ano=str(ano),
            sinopse=sinopse,
            capa=capa,
            fundo=fundo,
            mediatype="movie",
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series(filtro=""):
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")
    cat = carregar_catalogo()
    series = cat.get("series", [])

    # Barra de busca no topo de Séries
    lbl_busca = "[B][COLOR FFB565FF]🔍 Buscar Série...[/COLOR][/B]" if not filtro else f"[B][COLOR FFB565FF]🔍 Filtro: '{filtro}' (Limpar / Nova Busca)[/COLOR][/B]"
    item_b = xbmcgui.ListItem(label=lbl_busca)
    item_b.setArt({"icon": ICON_BUSCA, "thumb": ICON_BUSCA, "poster": ICON_BUSCA, "fanart": FANART_DEFAULT})
    item_b.setInfo("video", {"title": "Buscar Série", "plot": "Digite o nome da série para pesquisar."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="buscar_series"), listitem=item_b, isFolder=True)

    termo = filtro.strip().lower()
    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", "Sem Título")
        if termo and termo not in titulo.lower():
            continue
        ano = serie.get("ano", "")
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa") or ICON_DEFAULT
        fundo = serie.get("fundo") or FANART_DEFAULT
        label = f"[B]{titulo}[/B] ({ano})" if ano else f"[B]{titulo}[/B]"

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        info = {"title": titulo, "tvshowtitle": titulo, "plot": sinopse, "mediatype": "tvshow"}
        if str(ano).isdigit():
            info["year"] = int(ano)
        item.setInfo("video", info)

        url = get_url(action="temporadas", idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def buscar_series():
    kb = xbmc.Keyboard("", "Buscar Série no Cine Telona")
    kb.doModal()
    if kb.isConfirmed():
        texto = kb.getText()
        listar_series(filtro=texto)
    else:
        listar_series()


def listar_temporadas(idx):
    cat = carregar_catalogo()
    series = cat.get("series", [])
    if idx >= len(series):
        return
    serie = series[idx]
    titulo = serie.get("titulo", "Série")
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa") or ICON_DEFAULT
    fundo = serie.get("fundo") or FANART_DEFAULT
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else 999):
        item = xbmcgui.ListItem(label=f"[B][COLOR FF00E5FF]Temporada {temp_num}[/COLOR][/B]")
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {"title": f"Temporada {temp_num}", "tvshowtitle": titulo, "plot": sinopse, "mediatype": "season"})
        url = get_url(action="episodios", idx=idx, temp=temp_num)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(idx, temp):
    cat = carregar_catalogo()
    series = cat.get("series", [])
    if idx >= len(series):
        return
    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", "")
    capa = serie.get("capa") or ICON_DEFAULT
    fundo = serie.get("fundo") or FANART_DEFAULT
    eps = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{serie_titulo} - Temporada {temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for ep_idx, ep in enumerate(eps):
        ep_num = ep.get("episodio", ep_idx + 1)
        ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
        ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))
        ep_capa = ep.get("capa") or capa
        t_str = f"{int(temp):02d}" if str(temp).isdigit() else str(temp)
        e_str = f"{int(ep_num):02d}" if str(ep_num).isdigit() else str(ep_num)

        label = f"[COLOR FF00E5FF]{t_str}x{e_str}[/COLOR] - [B]{ep_titulo}[/B]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": ep_capa, "thumb": ep_capa, "poster": capa, "fanart": fundo})
        info = {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "plot": ep_sinopse,
            "season": int(temp) if str(temp).isdigit() else 1,
            "episode": int(ep_num) if str(ep_num).isdigit() else 1,
            "mediatype": "episode",
        }
        if str(ano).isdigit():
            info["year"] = int(ano)
        item.setInfo("video", info)

        opcoes = ep.get("opcoes", [])
        if opcoes:
            url = get_url(action="ep_opcoes", idx=idx, temp=temp, ep_idx=ep_idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        else:
            magnet = ep.get("magnet", "")
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet,
                titulo=f"{serie_titulo} - {t_str}x{e_str} - {ep_titulo}",
                tvshowtitle=serie_titulo,
                ano=str(ano),
                sinopse=ep_sinopse,
                capa=ep_capa,
                fundo=fundo,
                season=str(temp),
                episode=str(ep_num),
                mediatype="episode",
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_ep(idx, temp, ep_idx):
    cat = carregar_catalogo()
    series = cat.get("series", [])
    if idx >= len(series):
        return
    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", "")
    capa = serie.get("capa") or ICON_DEFAULT
    fundo = serie.get("fundo") or FANART_DEFAULT
    eps = serie.get("temporadas", {}).get(str(temp), [])
    if ep_idx >= len(eps):
        return
    ep = eps[ep_idx]
    ep_num = ep.get("episodio", ep_idx + 1)
    ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
    ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))

    xbmcplugin.setPluginCategory(HANDLE, ep_titulo)
    xbmcplugin.setContent(HANDLE, "episodes")

    for op in ep.get("opcoes", []):
        qual = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        item = xbmcgui.ListItem(label=f"[B]{ep_titulo}[/B]  -  [COLOR FF00E5FF]● {qual}[/COLOR]")
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {"title": ep_titulo, "tvshowtitle": serie_titulo, "plot": ep_sinopse, "mediatype": "episode"})
        item.setProperty("IsPlayable", "true")
        url = get_url(
            action="play",
            magnet=magnet,
            titulo=ep_titulo,
            tvshowtitle=serie_titulo,
            ano=str(ano),
            sinopse=ep_sinopse,
            capa=capa,
            fundo=fundo,
            season=str(temp),
            episode=str(ep_num),
            mediatype="episode",
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    if not magnet:
        xbmcgui.Dialog().notification("Cine Telona", "Link de vídeo indisponível.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Elementum Necessário",
                "Para reproduzir torrents, instale o add-on Elementum através do Repositório Telona."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote(magnet)}"
    else:
        play_path = magnet

    titulo = params.get("titulo", "Cine Telona")
    ano = params.get("ano", "")
    sinopse = params.get("sinopse", "")
    capa = params.get("capa", ICON_DEFAULT)
    fundo = params.get("fundo", FANART_DEFAULT)
    mediatype = params.get("mediatype", "movie")

    item = xbmcgui.ListItem(path=play_path)
    item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
    info = {"title": titulo, "plot": sinopse, "mediatype": mediatype}
    if str(ano).isdigit():
        info["year"] = int(ano)
    if mediatype == "episode":
        info["tvshowtitle"] = params.get("tvshowtitle", "")
        if str(params.get("season", "")).isdigit():
            info["season"] = int(params["season"])
        if str(params.get("episode", "")).isdigit():
            info["episode"] = int(params["episode"])
    item.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    if action == "boas_vindas":
        xbmcgui.Dialog().ok("Bem-vindo ao Cine Telona", "Explore nosso catálogo de Filmes e Séries com qualidade HD e 4K.")
    elif action == "filmes":
        listar_filmes()
    elif action == "buscar_filmes":
        buscar_filmes()
    elif action == "filme_opcoes":
        listar_opcoes_filme(int(params.get("idx", 0)))
    elif action == "series":
        listar_series()
    elif action == "buscar_series":
        buscar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("idx", 0)))
    elif action == "episodios":
        listar_episodios(int(params.get("idx", 0)), params.get("temp", "1"))
    elif action == "ep_opcoes":
        listar_opcoes_ep(int(params.get("idx", 0)), params.get("temp", "1"), int(params.get("ep_idx", 0)))
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
