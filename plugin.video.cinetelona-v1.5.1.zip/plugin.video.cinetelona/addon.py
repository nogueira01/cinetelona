import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")

ICON_DEFAULT = os.path.join(ADDON_PATH, "icon.png")
FANART_DEFAULT = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")

URL_CATALOGO_FIXA = "https://nogueira01.github.io/cinetelona/catalogo.json"

CATALOGO_FALLBACK = {
    "filmes": [],
    "series": []
}


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    try:
        req = urllib.request.Request(
            URL_CATALOGO_FIXA,
            headers={"User-Agent": "Mozilla/5.0 Kodi CineTelona/1.5.1"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            dados = json.loads(resp.read().decode("utf-8"))
            if isinstance(dados, dict):
                return dados
    except Exception:
        pass
    return CATALOGO_FALLBACK


def aplicar_painel_grande():
    xbmc.sleep(150)
    xbmc.executebuiltin("Container.SetViewMode(51)")


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "[COLOR FF00E5FF]CINE[/COLOR] [B][COLOR FFB565FF]TELONA[/COLOR][/B]")
    xbmcplugin.setContent(HANDLE, "videos")

    catalogo = carregar_catalogo()
    qtd_filmes = len(catalogo.get("filmes", []))
    qtd_series = len(catalogo.get("series", []))

    itens = [
        (
            f"[B][COLOR FF00E5FF]FILMES[/COLOR][/B] [COLOR FF8E9BAE]({qtd_filmes})[/COLOR]",
            get_url(action="filmes"),
            ICON_FILMES,
            "Explore o catálogo completo de filmes."
        ),
        (
            f"[B][COLOR FFB565FF]SÉRIES[/COLOR][/B] [COLOR FF8E9BAE]({qtd_series})[/COLOR]",
            get_url(action="series"),
            ICON_SERIES,
            "Explore séries organizadas por temporadas e episódios."
        ),
    ]

    for label, url, icon, plot in itens:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": icon, "icon": icon, "poster": icon, "fanart": FANART_DEFAULT})
        li.setInfo("video", {"title": label, "plot": plot})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")
    catalogo = carregar_catalogo()

    for idx, filme in enumerate(catalogo.get("filmes", [])):
        titulo = filme.get("titulo", "Sem Título")
        ano = filme.get("ano", "")
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa") or ICON_DEFAULT
        fundo = filme.get("fundo") or FANART_DEFAULT

        label = f"[B]{titulo}[/B] [COLOR FF00E5FF]({ano})[/COLOR]" if ano else f"[B]{titulo}[/B]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": capa, "icon": capa, "poster": capa, "fanart": fundo})

        info = {"title": titulo, "plot": sinopse, "mediatype": "movie"}
        if str(ano).isdigit():
            info["year"] = int(ano)
        li.setInfo("video", info)

        opcoes = filme.get("opcoes")
        if opcoes and isinstance(opcoes, list):
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        else:
            magnet = filme.get("magnet", "")
            li.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet,
                title=titulo,
                year=str(ano),
                plot=sinopse,
                poster=capa,
                fanart=fundo,
                mediatype="movie"
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def formatar_qualidade(qual):
    q_up = str(qual).upper()
    if "4K" in q_up or "2160" in q_up:
        return f"[COLOR FFFFD700]★ {qual}[/COLOR]"
    if "FULL" in q_up:
        return f"[COLOR FFB565FF]◆ {qual}[/COLOR]"
    return f"[COLOR FF00E5FF]● {qual}[/COLOR]"


def listar_opcoes_filme(idx):
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", "")
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_DEFAULT
    fundo = filme.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for op in filme.get("opcoes", []):
        qual = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        label = f"[B]{titulo}[/B]  -  {formatar_qualidade(qual)}"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": capa, "icon": capa, "poster": capa, "fanart": fundo})
        info = {"title": titulo, "plot": sinopse, "mediatype": "movie"}
        if str(ano).isdigit():
            info["year"] = int(ano)
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            title=titulo,
            year=str(ano),
            plot=sinopse,
            poster=capa,
            fanart=fundo,
            mediatype="movie"
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")
    catalogo = carregar_catalogo()

    for idx, serie in enumerate(catalogo.get("series", [])):
        titulo = serie.get("titulo", "Sem Título")
        ano = serie.get("ano", "")
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa") or ICON_DEFAULT
        fundo = serie.get("fundo") or FANART_DEFAULT

        label = f"[B]{titulo}[/B] [COLOR FFB565FF]({ano})[/COLOR]" if ano else f"[B]{titulo}[/B]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": capa, "icon": capa, "poster": capa, "fanart": fundo})
        info = {"title": titulo, "tvshowtitle": titulo, "plot": sinopse, "mediatype": "tvshow"}
        if str(ano).isdigit():
            info["year"] = int(ano)
        li.setInfo("video", info)

        url = get_url(action="temporadas", idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_temporadas(idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    titulo = serie.get("titulo", "Série")
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa") or ICON_DEFAULT
    fundo = serie.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    temporadas = serie.get("temporadas", {})
    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else 0):
        label = f"[B][COLOR FF00E5FF]Temporada {temp_num}[/COLOR][/B]  [COLOR FF8E9BAE]({len(temporadas[temp_num])} episódios)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": capa, "icon": capa, "poster": capa, "fanart": fundo})
        li.setInfo("video", {"title": f"Temporada {temp_num}", "tvshowtitle": titulo, "plot": sinopse, "mediatype": "season"})

        url = get_url(action="episodios", idx=idx, temp=temp_num)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(idx, temp):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", "")
    capa = serie.get("capa") or ICON_DEFAULT
    fundo = serie.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, f"{serie_titulo} - T{temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    episodios = serie.get("temporadas", {}).get(str(temp), [])
    for ep_idx, ep in enumerate(episodios):
        ep_num = ep.get("episodio", ep_idx + 1)
        ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
        ep_sinopse = ep.get("sinopse") or serie.get("sinopse", "")
        ep_thumb = ep.get("capa") or capa

        prefixo = f"[COLOR FFB565FF]{int(temp):02d}x{int(ep_num):02d}[/COLOR]" if str(temp).isdigit() and str(ep_num).isdigit() else f"{temp}x{ep_num}"
        label = f"{prefixo}  -  [B]{ep_titulo}[/B]"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": ep_thumb, "icon": ep_thumb, "poster": capa, "fanart": fundo})
        info = {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "plot": ep_sinopse,
            "mediatype": "episode"
        }
        if str(temp).isdigit():
            info["season"] = int(temp)
        if str(ep_num).isdigit():
            info["episode"] = int(ep_num)
        if str(ano).isdigit():
            info["year"] = int(ano)
        li.setInfo("video", info)

        opcoes = ep.get("opcoes")
        if opcoes and isinstance(opcoes, list):
            url = get_url(action="opcoes_episodio", idx=idx, temp=temp, ep_idx=ep_idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        else:
            magnet = ep.get("magnet", "")
            li.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet,
                title=ep_titulo,
                tvshowtitle=serie_titulo,
                season=str(temp),
                episode=str(ep_num),
                year=str(ano),
                plot=ep_sinopse,
                poster=capa,
                fanart=fundo,
                mediatype="episode"
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_episodio(idx, temp, ep_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", "")
    capa = serie.get("capa") or ICON_DEFAULT
    fundo = serie.get("fundo") or FANART_DEFAULT
    episodios = serie.get("temporadas", {}).get(str(temp), [])
    if ep_idx < 0 or ep_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[ep_idx]
    ep_num = ep.get("episodio", ep_idx + 1)
    ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
    ep_sinopse = ep.get("sinopse") or serie.get("sinopse", "")

    xbmcplugin.setPluginCategory(HANDLE, ep_titulo)
    xbmcplugin.setContent(HANDLE, "episodes")

    for op in ep.get("opcoes", []):
        qual = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        label = f"[B]{ep_titulo}[/B]  -  {formatar_qualidade(qual)}"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": capa, "icon": capa, "poster": capa, "fanart": fundo})
        info = {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "plot": ep_sinopse,
            "mediatype": "episode"
        }
        if str(temp).isdigit():
            info["season"] = int(temp)
        if str(ep_num).isdigit():
            info["episode"] = int(ep_num)
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            title=ep_titulo,
            tvshowtitle=serie_titulo,
            season=str(temp),
            episode=str(ep_num),
            year=str(ano),
            plot=ep_sinopse,
            poster=capa,
            fanart=fundo,
            mediatype="episode"
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    if not magnet:
        xbmcgui.Dialog().notification("Cine Telona", "Link de vídeo vazio.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "O add-on [B]Elementum[/B] não está instalado ou ativado no seu Kodi. Instale o Elementum para reproduzir torrents."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote(magnet)}"
    else:
        play_path = magnet

    titulo = params.get("title", "Cine Telona")
    poster = params.get("poster") or ICON_DEFAULT
    fanart = params.get("fanart") or FANART_DEFAULT
    mediatype = params.get("mediatype", "movie")

    li = xbmcgui.ListItem(path=play_path)
    li.setArt({"thumb": poster, "icon": poster, "poster": poster, "fanart": fanart})

    info = {
        "title": titulo,
        "plot": params.get("plot", ""),
        "mediatype": mediatype
    }
    if params.get("tvshowtitle"):
        info["tvshowtitle"] = params["tvshowtitle"]
    if str(params.get("year", "")).isdigit():
        info["year"] = int(params["year"])
    if str(params.get("season", "")).isdigit():
        info["season"] = int(params["season"])
    if str(params.get("episode", "")).isdigit():
        info["episode"] = int(params["episode"])

    li.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", -1)))
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("idx", -1)), params.get("temp", "1"))
    elif action == "opcoes_episodio":
        listar_opcoes_episodio(int(params.get("idx", -1)), params.get("temp", "1"), int(params.get("ep_idx", -1)))
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[1][1:] if len(sys.argv) > 1 and sys.argv[1].startswith("?") else "")
