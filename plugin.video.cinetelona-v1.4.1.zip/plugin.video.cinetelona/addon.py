import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
URL_CATALOGO = "https://nogueira01.github.io/cinetelona/catalogo.json"

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
if not os.path.exists(PROFILE_DIR):
    os.makedirs(PROFILE_DIR)
CACHE_FILE = os.path.join(PROFILE_DIR, "catalogo_cache.json")
LOCAL_FALLBACK = os.path.join(ADDON.getAddonInfo("path"), "catalogo.json")


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def aplicar_painel_grande():
    skin = xbmc.getSkinDir()
    if "estuary" in skin.lower():
        xbmc.executebuiltin("Container.SetViewMode(51)")
    else:
        xbmc.executebuiltin("Container.SetViewMode(500)")


def carregar_catalogo():
    try:
        req = urllib.request.Request(
            URL_CATALOGO,
            headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            data = json.loads(raw)
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                f.write(raw)
            return data
    except Exception:
        if os.path.exists(CACHE_FILE):
            try:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        if os.path.exists(LOCAL_FALLBACK):
            with open(LOCAL_FALLBACK, "r", encoding="utf-8") as f:
                return json.load(f)
    return {"filmes": [], "series": []}


def aplicar_metadados(item, info_dict, media_type="movie"):
    titulo = info_dict.get("titulo", "")
    ano = info_dict.get("ano", 0)
    sinopse = info_dict.get("sinopse", "")
    capa = info_dict.get("capa", "")
    fundo = info_dict.get("fundo", "")

    art = {}
    if capa:
        art["thumb"] = capa
        art["poster"] = capa
        art["icon"] = capa
    if fundo:
        art["fanart"] = fundo
    if art:
        item.setArt(art)

    video_info = {
        "title": titulo,
        "originaltitle": titulo,
        "plot": sinopse,
        "plotoutline": sinopse,
        "mediatype": media_type,
    }
    if ano:
        try:
            video_info["year"] = int(ano)
        except Exception:
            pass
    if "tvshowtitle" in info_dict:
        video_info["tvshowtitle"] = info_dict["tvshowtitle"]
    if "season" in info_dict:
        video_info["season"] = int(info_dict["season"])
    if "episode" in info_dict:
        video_info["episode"] = int(info_dict["episode"])

    item.setInfo("video", video_info)


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    item_filmes = xbmcgui.ListItem(label="Filmes")
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=get_url(action="filmes"),
        listitem=item_filmes,
        isFolder=True
    )

    item_series = xbmcgui.ListItem(label="Séries")
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=get_url(action="series"),
        listitem=item_series,
        isFolder=True
    )

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])

    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")

    for idx, filme in enumerate(filmes):
        titulo = filme.get("titulo", f"Filme {idx + 1}")
        ano = filme.get("ano", "")
        label = f"{titulo} ({ano})" if ano else titulo

        item = xbmcgui.ListItem(label=label)
        aplicar_metadados(item, filme, media_type="movie")

        opcoes = filme.get("opcoes", [])
        magnet = filme.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        elif magnet:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet,
                titulo=titulo,
                ano=str(ano),
                sinopse=filme.get("sinopse", ""),
                capa=filme.get("capa", ""),
                fundo=filme.get("fundo", ""),
                mediatype="movie"
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_opcoes_filme(idx):
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", "")
    opcoes = filme.get("opcoes", [])

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "videos")

    for op in opcoes:
        qualidade = op.get("qualidade", "Padrão")
        magnet = op.get("magnet", "")
        if not magnet:
            continue

        label = f"{titulo} - [{qualidade}]"
        item = xbmcgui.ListItem(label=label)
        aplicar_metadados(item, filme, media_type="movie")
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            titulo=titulo,
            ano=str(ano),
            sinopse=filme.get("sinopse", ""),
            capa=filme.get("capa", ""),
            fundo=filme.get("fundo", ""),
            mediatype="movie"
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])

    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")

    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", f"Série {idx + 1}")
        ano = serie.get("ano", "")
        label = f"{titulo} ({ano})" if ano else titulo

        item = xbmcgui.ListItem(label=label)
        aplicar_metadados(item, serie, media_type="tvshow")

        url = get_url(action="temporadas", s_idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_temporadas(s_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo_serie = serie.get("titulo", "Série")
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo_serie)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else str(x)):
        label = f"Temporada {temp_num}"
        item = xbmcgui.ListItem(label=label)
        info_temp = dict(serie)
        info_temp["titulo"] = label
        info_temp["tvshowtitle"] = titulo_serie
        if str(temp_num).isdigit():
            info_temp["season"] = int(temp_num)
        aplicar_metadados(item, info_temp, media_type="season")

        url = get_url(action="episodios", s_idx=s_idx, temp=str(temp_num))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(s_idx, temp):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo_serie = serie.get("titulo", "Série")
    episodios = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{titulo_serie} - Temporada {temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for ep_idx, ep in enumerate(episodios):
        num_ep = ep.get("episodio", ep_idx + 1)
        titulo_ep = ep.get("titulo", f"Episódio {num_ep}")
        label = f"{int(temp)}x{int(num_ep):02d} - {titulo_ep}" if str(temp).isdigit() and str(num_ep).isdigit() else f"{num_ep} - {titulo_ep}"

        sinopse_ep = ep.get("sinopse") or serie.get("sinopse", "")
        capa_ep = ep.get("capa") or serie.get("capa", "")
        fundo_ep = ep.get("fundo") or serie.get("fundo", "")

        info_ep = {
            "titulo": titulo_ep,
            "tvshowtitle": titulo_serie,
            "ano": serie.get("ano", 0),
            "sinopse": sinopse_ep,
            "capa": capa_ep,
            "fundo": fundo_ep,
            "season": int(temp) if str(temp).isdigit() else 1,
            "episode": int(num_ep) if str(num_ep).isdigit() else ep_idx + 1,
        }

        item = xbmcgui.ListItem(label=label)
        aplicar_metadados(item, info_ep, media_type="episode")

        opcoes = ep.get("opcoes", [])
        magnet = ep.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_ep", s_idx=s_idx, temp=str(temp), ep_idx=ep_idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        elif magnet:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet,
                titulo=titulo_ep,
                tvshowtitle=titulo_serie,
                ano=str(serie.get("ano", "")),
                sinopse=sinopse_ep,
                capa=capa_ep,
                fundo=fundo_ep,
                season=str(info_ep["season"]),
                episode=str(info_ep["episode"]),
                mediatype="episode"
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_episodio(s_idx, temp, ep_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo_serie = serie.get("titulo", "Série")
    episodios = serie.get("temporadas", {}).get(str(temp), [])
    if ep_idx < 0 or ep_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[ep_idx]
    num_ep = ep.get("episodio", ep_idx + 1)
    titulo_ep = ep.get("titulo", f"Episódio {num_ep}")
    sinopse_ep = ep.get("sinopse") or serie.get("sinopse", "")
    capa_ep = ep.get("capa") or serie.get("capa", "")
    fundo_ep = ep.get("fundo") or serie.get("fundo", "")
    opcoes = ep.get("opcoes", [])

    xbmcplugin.setPluginCategory(HANDLE, titulo_ep)
    xbmcplugin.setContent(HANDLE, "videos")

    for op in opcoes:
        qualidade = op.get("qualidade", "Padrão")
        magnet = op.get("magnet", "")
        if not magnet:
            continue

        label = f"{titulo_ep} - [{qualidade}]"
        info_ep = {
            "titulo": titulo_ep,
            "tvshowtitle": titulo_serie,
            "ano": serie.get("ano", 0),
            "sinopse": sinopse_ep,
            "capa": capa_ep,
            "fundo": fundo_ep,
            "season": int(temp) if str(temp).isdigit() else 1,
            "episode": int(num_ep) if str(num_ep).isdigit() else ep_idx + 1,
        }
        item = xbmcgui.ListItem(label=label)
        aplicar_metadados(item, info_ep, media_type="episode")
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            titulo=titulo_ep,
            tvshowtitle=titulo_serie,
            ano=str(serie.get("ano", "")),
            sinopse=sinopse_ep,
            capa=capa_ep,
            fundo=fundo_ep,
            season=str(info_ep["season"]),
            episode=str(info_ep["episode"]),
            mediatype="episode"
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    if not magnet:
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "O add-on Elementum não está instalado no seu Kodi. Instale o Elementum para reproduzir links torrent."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote(magnet)}"
    else:
        play_path = magnet

    item = xbmcgui.ListItem(path=play_path)
    info_dict = {
        "titulo": params.get("titulo", "Cine Telona"),
        "ano": params.get("ano", 0),
        "sinopse": params.get("sinopse", ""),
        "capa": params.get("capa", ""),
        "fundo": params.get("fundo", ""),
    }
    if params.get("tvshowtitle"):
        info_dict["tvshowtitle"] = params["tvshowtitle"]
    if params.get("season"):
        info_dict["season"] = params["season"]
    if params.get("episode"):
        info_dict["episode"] = params["episode"]

    aplicar_metadados(item, info_dict, media_type=params.get("mediatype", "movie"))
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", -1)))
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("s_idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("s_idx", -1)), params.get("temp", "1"))
    elif action == "opcoes_ep":
        listar_opcoes_episodio(
            int(params.get("s_idx", -1)),
            params.get("temp", "1"),
            int(params.get("ep_idx", -1))
        )
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
