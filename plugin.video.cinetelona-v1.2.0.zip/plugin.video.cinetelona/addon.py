import sys
import os
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

URL_CATALOGO = "https://nogueira01.github.io/cinetelona/catalogo.json"
CACHE_FILE = os.path.join(PROFILE_PATH, "catalogo_cache.json")
LOCAL_FALLBACK = os.path.join(ADDON_PATH, "catalogo.json")


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    if not os.path.exists(PROFILE_PATH):
        os.makedirs(PROFILE_PATH, exist_ok=True)

    try:
        req = urllib.request.Request(
            URL_CATALOGO,
            headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            conteudo = resp.read().decode("utf-8")
            dados = json.loads(conteudo)
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                f.write(conteudo)
            return dados
    except Exception as e:
        xbmc.log(f"[CineTelona] Falha ao baixar catalogo remoto: {e}", xbmc.LOGWARNING)

    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    if os.path.exists(LOCAL_FALLBACK):
        try:
            with open(LOCAL_FALLBACK, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    return {"filmes": [], "series": []}


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    itens = [
        ("Filmes", "filmes"),
        ("Séries", "series"),
    ]

    for titulo, action in itens:
        li = xbmcgui.ListItem(label=titulo)
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])

    for filme in filmes:
        titulo = filme.get("titulo", "Sem Título")
        ano = filme.get("ano", "")
        label = f"{titulo} ({ano})" if ano else titulo
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa", "")
        fundo = filme.get("fundo", "")
        magnet = filme.get("magnet", "")

        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {
            "title": titulo,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": sinopse,
            "mediatype": "movie"
        })
        art = {}
        if capa:
            art["thumb"] = capa
            art["poster"] = capa
        if fundo:
            art["fanart"] = fundo
        if art:
            li.setArt(art)

        li.setProperty("IsPlayable", "true")
        play_url = get_url(action="play", link=magnet)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])

    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", "Sem Título")
        ano = serie.get("ano", "")
        label = f"{titulo} ({ano})" if ano else titulo
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa", "")
        fundo = serie.get("fundo", "")

        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {
            "title": titulo,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": sinopse,
            "mediatype": "tvshow"
        })
        art = {}
        if capa:
            art["thumb"] = capa
            art["poster"] = capa
        if fundo:
            art["fanart"] = fundo
        if art:
            li.setArt(art)

        url = get_url(action="temporadas", serie_idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_temporadas(serie_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if serie_idx < 0 or serie_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[serie_idx]
    titulo_serie = serie.get("titulo", "Série")
    capa = serie.get("capa", "")
    fundo = serie.get("fundo", "")
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo_serie)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
        label = f"Temporada {temp_num}"
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": label, "tvshowtitle": titulo_serie, "mediatype": "season"})
        art = {}
        if capa:
            art["thumb"] = capa
            art["poster"] = capa
        if fundo:
            art["fanart"] = fundo
        if art:
            li.setArt(art)

        url = get_url(action="episodios", serie_idx=serie_idx, temp=temp_num)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(serie_idx, temp_num):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if serie_idx < 0 or serie_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[serie_idx]
    titulo_serie = serie.get("titulo", "Série")
    capa = serie.get("capa", "")
    fundo = serie.get("fundo", "")
    episodios = serie.get("temporadas", {}).get(str(temp_num), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{titulo_serie} - Temporada {temp_num}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for ep in episodios:
        num = ep.get("episodio", "")
        titulo_ep = ep.get("titulo", f"Episódio {num}")
        label = f"{int(num):02d} - {titulo_ep}" if str(num).isdigit() else titulo_ep
        sinopse = ep.get("sinopse", "")
        magnet = ep.get("magnet", "")

        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {
            "title": titulo_ep,
            "tvshowtitle": titulo_serie,
            "season": int(temp_num) if str(temp_num).isdigit() else 1,
            "episode": int(num) if str(num).isdigit() else 1,
            "plot": sinopse,
            "mediatype": "episode"
        })
        art = {}
        if capa:
            art["thumb"] = capa
            art["poster"] = capa
        if fundo:
            art["fanart"] = fundo
        if art:
            li.setArt(art)

        li.setProperty("IsPlayable", "true")
        play_url = get_url(action="play", link=magnet)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(link):
    if not link:
        xbmcgui.Dialog().notification("Cine Telona", "Link de vídeo não informado.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if link.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "Para reproduzir links torrent (magnet), instale primeiro o add-on Elementum no Kodi."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        uri_encoded = urllib.parse.quote_plus(link)
        final_url = f"plugin://plugin.video.elementum/play?uri={uri_encoded}"
    else:
        final_url = link

    li = xbmcgui.ListItem(path=final_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "filmes":
        listar_filmes()
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("serie_idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("serie_idx", -1)), params.get("temp", "1"))
    elif action == "play":
        reproduzir(params.get("link", ""))
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[1:])
