import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
ICON_DEFAULT = os.path.join(ADDON_PATH, "icon.png")
FANART_DEFAULT = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")
CATALOGO_LOCAL = os.path.join(ADDON_PATH, "catalogo.json")

URL_CATALOGO_FIXA = "https://nogueira01.github.io/cinetelona/catalogo.json"


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    try:
        req = urllib.request.Request(
            URL_CATALOGO_FIXA,
            headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            dados = json.loads(raw)
            if isinstance(dados, dict) and ("filmes" in dados or "series" in dados):
                return dados
    except Exception:
        pass

    try:
        with open(CATALOGO_LOCAL, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"filmes": [], "series": []}


def aplicar_painel_grande():
    skin = xbmc.getSkinDir()
    view_id = 51 if "estuary" in skin.lower() else 500
    xbmc.executebuiltin(f"Container.SetViewMode({view_id})")


def definir_metadados(item, info_dict):
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(info_dict.get("title", ""))
        if info_dict.get("tvshowtitle"):
            tag.setTvShowTitle(info_dict["tvshowtitle"])
        if info_dict.get("plot"):
            tag.setPlot(info_dict["plot"])
        if info_dict.get("year"):
            tag.setYear(int(info_dict["year"]))
        if info_dict.get("season") is not None:
            tag.setSeason(int(info_dict["season"]))
        if info_dict.get("episode") is not None:
            tag.setEpisode(int(info_dict["episode"]))
        if info_dict.get("mediatype"):
            tag.setMediaType(info_dict["mediatype"])
    except Exception:
        item.setInfo("video", info_dict)


def formatar_selo_qualidade(qualidade):
    q = str(qualidade).strip()
    q_low = q.lower()
    if "4k" in q_low or "2160" in q_low:
        return f"[COLOR FFFFD700]★ {q}[/COLOR]"
    if "full" in q_low:
        return f"[COLOR FFB565FF]◆ {q}[/COLOR]"
    return f"[COLOR FF00E5FF]● {q}[/COLOR]"


def menu_principal():
    dados = carregar_catalogo()
    total_filmes = len(dados.get("filmes", []))
    total_series = len(dados.get("series", []))

    xbmcplugin.setPluginCategory(HANDLE, "[COLOR FF00E5FF]CINE[/COLOR] [COLOR FFB565FF]TELONA[/COLOR]")
    xbmcplugin.setContent(HANDLE, "files")

    item_filmes = xbmcgui.ListItem(
        label=f"[B][COLOR FF00E5FF]FILMES[/COLOR][/B]  [COLOR FF9E9E9E]({total_filmes} disponíveis)[/COLOR]"
    )
    item_filmes.setArt({"icon": ICON_FILMES, "thumb": ICON_FILMES, "poster": ICON_FILMES, "fanart": FANART_DEFAULT})
    definir_metadados(item_filmes, {
        "title": "Filmes",
        "plot": "Explore o catálogo completo de filmes em 1080p, 1080p Full e 4K."
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action="filmes"), item_filmes, isFolder=True)

    item_series = xbmcgui.ListItem(
        label=f"[B][COLOR FFB565FF]SÉRIES[/COLOR][/B]  [COLOR FF9E9E9E]({total_series} disponíveis)[/COLOR]"
    )
    item_series.setArt({"icon": ICON_SERIES, "thumb": ICON_SERIES, "poster": ICON_SERIES, "fanart": FANART_DEFAULT})
    definir_metadados(item_series, {
        "title": "Séries",
        "plot": "Assista às séries organizadas por temporadas e episódios."
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action="series"), item_series, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    dados = carregar_catalogo()
    filmes = dados.get("filmes", [])

    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")

    for idx, filme in enumerate(filmes):
        titulo = filme.get("titulo", "Sem Título")
        ano = filme.get("ano", 0)
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa") or ICON_FILMES
        fundo = filme.get("fundo") or FANART_DEFAULT
        opcoes = filme.get("opcoes", [])
        magnet_unico = filme.get("magnet", "")

        label = f"[B]{titulo}[/B]"
        if ano:
            label += f" [COLOR FF00E5FF]({ano})[/COLOR]"

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        definir_metadados(item, {
            "title": titulo,
            "year": ano,
            "plot": sinopse,
            "mediatype": "movie"
        })

        if opcoes:
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
        else:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet_unico,
                title=titulo,
                year=ano,
                plot=sinopse,
                poster=capa,
                fanart=fundo,
                mediatype="movie"
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_opcoes_filme(idx):
    dados = carregar_catalogo()
    filmes = dados.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", 0)
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_FILMES
    fundo = filme.get("fundo") or FANART_DEFAULT
    opcoes = filme.get("opcoes", [])

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for opc in opcoes:
        qualidade = opc.get("qualidade", "HD")
        magnet = opc.get("magnet", "")
        if not magnet:
            continue

        selo = formatar_selo_qualidade(qualidade)
        label = f"{titulo}  -  [B]{selo}[/B]"

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setProperty("IsPlayable", "true")
        definir_metadados(item, {
            "title": f"{titulo} ({qualidade})",
            "year": ano,
            "plot": sinopse,
            "mediatype": "movie"
        })

        url = get_url(
            action="play",
            magnet=magnet,
            title=titulo,
            year=ano,
            plot=sinopse,
            poster=capa,
            fanart=fundo,
            mediatype="movie"
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    dados = carregar_catalogo()
    series = dados.get("series", [])

    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")

    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", "Sem Título")
        ano = serie.get("ano", 0)
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa") or ICON_SERIES
        fundo = serie.get("fundo") or FANART_DEFAULT

        label = f"[B]{titulo}[/B]"
        if ano:
            label += f" [COLOR FFB565FF]({ano})[/COLOR]"

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        definir_metadados(item, {
            "title": titulo,
            "tvshowtitle": titulo,
            "year": ano,
            "plot": sinopse,
            "mediatype": "tvshow"
        })

        url = get_url(action="temporadas", idx=idx)
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_temporadas(idx):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else 999):
        eps = temporadas[temp_num]
        label = f"[B][COLOR FF00E5FF]Temporada {temp_num}[/COLOR][/B]  [COLOR FF9E9E9E]({len(eps)} episódios)[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        definir_metadados(item, {
            "title": f"Temporada {temp_num}",
            "tvshowtitle": titulo,
            "year": ano,
            "season": int(temp_num) if str(temp_num).isdigit() else 1,
            "plot": sinopse,
            "mediatype": "season"
        })
        url = get_url(action="episodios", idx=idx, temp=temp_num)
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(idx, temp):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    episodios = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{serie_titulo} - Temporada {temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    temp_int = int(temp) if str(temp).isdigit() else 1

    for ep_idx, ep in enumerate(episodios):
        ep_num = ep.get("episodio", ep_idx + 1)
        ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
        ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))
        opcoes = ep.get("opcoes", [])
        magnet_unico = ep.get("magnet", "")

        label = f"[B][COLOR FF00E5FF]{temp_int:02d}x{int(ep_num):02d}[/COLOR][/B] - {ep_titulo}"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        definir_metadados(item, {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "year": ano,
            "season": temp_int,
            "episode": int(ep_num),
            "plot": ep_sinopse,
            "mediatype": "episode"
        })

        if opcoes:
            url = get_url(action="opcoes_episodio", idx=idx, temp=temp, ep_idx=ep_idx)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
        else:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet_unico,
                title=ep_titulo,
                tvshowtitle=serie_titulo,
                year=ano,
                season=temp_int,
                episode=int(ep_num),
                plot=ep_sinopse,
                poster=capa,
                fanart=fundo,
                mediatype="episode"
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_episodio(idx, temp, ep_idx):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    episodios = serie.get("temporadas", {}).get(str(temp), [])
    if ep_idx < 0 or ep_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[ep_idx]
    ep_num = ep.get("episodio", ep_idx + 1)
    ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
    ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))
    opcoes = ep.get("opcoes", [])
    temp_int = int(temp) if str(temp).isdigit() else 1

    xbmcplugin.setPluginCategory(HANDLE, ep_titulo)
    xbmcplugin.setContent(HANDLE, "episodes")

    for opc in opcoes:
        qualidade = opc.get("qualidade", "HD")
        magnet = opc.get("magnet", "")
        if not magnet:
            continue

        selo = formatar_selo_qualidade(qualidade)
        label = f"{ep_titulo}  -  [B]{selo}[/B]"

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setProperty("IsPlayable", "true")
        definir_metadados(item, {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "year": ano,
            "season": temp_int,
            "episode": int(ep_num),
            "plot": ep_sinopse,
            "mediatype": "episode"
        })

        url = get_url(
            action="play",
            magnet=magnet,
            title=ep_titulo,
            tvshowtitle=serie_titulo,
            year=ano,
            season=temp_int,
            episode=int(ep_num),
            plot=ep_sinopse,
            poster=capa,
            fanart=fundo,
            mediatype="episode"
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    if not magnet:
        xbmcgui.Dialog().notification("Cine Telona", "Link de vídeo não encontrado.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "O add-on Elementum não está instalado no seu Kodi. Instale o Elementum para reproduzir links torrent."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote_plus(magnet)}"
    else:
        play_path = magnet

    titulo = params.get("title", "Cine Telona")
    poster = params.get("poster", ICON_DEFAULT)
    fanart = params.get("fanart", FANART_DEFAULT)

    item = xbmcgui.ListItem(label=titulo, path=play_path)
    item.setArt({"icon": poster, "thumb": poster, "poster": poster, "fanart": fanart})
    definir_metadados(item, {
        "title": titulo,
        "tvshowtitle": params.get("tvshowtitle", ""),
        "year": int(params["year"]) if params.get("year") and str(params["year"]).isdigit() else 0,
        "season": int(params["season"]) if params.get("season") and str(params["season"]).isdigit() else None,
        "episode": int(params["episode"]) if params.get("episode") and str(params["episode"]).isdigit() else None,
        "plot": params.get("plot", ""),
        "mediatype": params.get("mediatype", "movie")
    })
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip("?")))
    action = params.get("action")

    if action == "filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", -1)))
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("idx", -1)), params.get("temp", "1"))
    elif action == "opcoes_episodio":
        listar_opcoes_episodio(int(params.get("idx", -1)), params.get("temp", "1"), int(params.get("ep_idx", -1)))
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[2] if len(sys.argv) > 2 else "")
