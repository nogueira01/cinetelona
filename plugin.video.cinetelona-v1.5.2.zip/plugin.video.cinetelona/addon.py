import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

URL_CATALOGO_REMOTO = "https://nogueira01.github.io/cinetelona/catalogo.json"
ICON_PADRAO = os.path.join(ADDON_PATH, "icon.png")
FANART_PADRAO = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")
CACHE_FILE = os.path.join(PROFILE_PATH, "catalogo_cache.json")


def get_url(**kwargs):
    return "{0}?{1}".format(BASE_URL, urllib.parse.urlencode(kwargs))


def carregar_catalogo():
    if not os.path.exists(PROFILE_PATH):
        try:
            os.makedirs(PROFILE_PATH)
        except Exception:
            pass

    try:
        req = urllib.request.Request(
            URL_CATALOGO_REMOTO,
            headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            dados = json.loads(raw)
            if isinstance(dados, dict) and ("filmes" in dados or "series" in dados):
                try:
                    with open(CACHE_FILE, "w", encoding="utf-8") as f:
                        f.write(raw)
                except Exception:
                    pass
                return dados
    except Exception:
        pass

    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    local_default = os.path.join(ADDON_PATH, "catalogo.json")
    if os.path.exists(local_default):
        try:
            with open(local_default, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    return {"filmes": [], "series": []}


def aplicar_painel_grande():
    try:
        xbmc.executebuiltin("Container.SetViewMode(51)")
    except Exception:
        pass


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "files")

    catalogo = carregar_catalogo()
    qtd_filmes = len(catalogo.get("filmes", []))
    qtd_series = len(catalogo.get("series", []))

    item_filmes = xbmcgui.ListItem(
        label="[B][COLOR FF00E5FF]FILMES[/COLOR][/B]  [COLOR FF90A4AE]({0} disponíveis)[/COLOR]".format(qtd_filmes)
    )
    item_filmes.setArt({
        "icon": ICON_FILMES if os.path.exists(ICON_FILMES) else ICON_PADRAO,
        "thumb": ICON_FILMES if os.path.exists(ICON_FILMES) else ICON_PADRAO,
        "fanart": FANART_PADRAO
    })
    item_filmes.setInfo("video", {"plot": "Catálogo completo de filmes em alta definição."})
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=get_url(action="listar_filmes"),
        listitem=item_filmes,
        isFolder=True
    )

    item_series = xbmcgui.ListItem(
        label="[B][COLOR FFB565FF]SÉRIES[/COLOR][/B]  [COLOR FF90A4AE]({0} disponíveis)[/COLOR]".format(qtd_series)
    )
    item_series.setArt({
        "icon": ICON_SERIES if os.path.exists(ICON_SERIES) else ICON_PADRAO,
        "thumb": ICON_SERIES if os.path.exists(ICON_SERIES) else ICON_PADRAO,
        "fanart": FANART_PADRAO
    })
    item_series.setInfo("video", {"plot": "Séries organizadas por temporadas e episódios."})
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=get_url(action="listar_series"),
        listitem=item_series,
        isFolder=True
    )

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")

    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])

    for idx, filme in enumerate(filmes):
        titulo = filme.get("titulo", "Sem Título")
        ano = filme.get("ano", 0)
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa") or ICON_PADRAO
        fundo = filme.get("fundo") or FANART_PADRAO

        label = "[B]{0}[/B] [COLOR FF00E5FF]({1})[/COLOR]".format(titulo, ano) if ano else "[B]{0}[/B]".format(titulo)
        item = xbmcgui.ListItem(label=label)
        item.setArt({"poster": capa, "thumb": capa, "icon": capa, "fanart": fundo})
        info = {"title": titulo, "plot": sinopse, "mediatype": "movie"}
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        item.setInfo("video", info)

        opcoes = filme.get("opcoes", [])
        magnet_unico = filme.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        elif magnet_unico:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet_unico,
                titulo=titulo,
                ano=str(ano),
                sinopse=sinopse,
                capa=capa,
                fundo=fundo,
                mediatype="movie"
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def formatar_selo_qualidade(qualidade):
    q_lower = qualidade.lower()
    if "4k" in q_lower or "2160" in q_lower:
        return "[B][COLOR FFFFD54F]★ {0}[/COLOR][/B]".format(qualidade)
    elif "full" in q_lower:
        return "[B][COLOR FFB565FF]◆ {0}[/COLOR][/B]".format(qualidade)
    return "[B][COLOR FF00E5FF]● {0}[/COLOR][/B]".format(qualidade)


def opcoes_filme(idx):
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", 0)
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_PADRAO
    fundo = filme.get("fundo") or FANART_PADRAO

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for op in filme.get("opcoes", []):
        qualidade = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        if not magnet:
            continue

        selo = formatar_selo_qualidade(qualidade)
        label = "{0}  -  {1}".format(titulo, selo)
        item = xbmcgui.ListItem(label=label)
        item.setArt({"poster": capa, "thumb": capa, "icon": capa, "fanart": fundo})
        info = {"title": titulo, "plot": sinopse, "mediatype": "movie"}
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        item.setInfo("video", info)
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            titulo=titulo,
            ano=str(ano),
            sinopse=sinopse,
            capa=capa,
            fundo=fundo,
            mediatype="movie"
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")

    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])

    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", "Sem Título")
        ano = serie.get("ano", 0)
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa") or ICON_PADRAO
        fundo = serie.get("fundo") or FANART_PADRAO

        label = "[B]{0}[/B] [COLOR FFB565FF]({1})[/COLOR]".format(titulo, ano) if ano else "[B]{0}[/B]".format(titulo)
        item = xbmcgui.ListItem(label=label)
        item.setArt({"poster": capa, "thumb": capa, "icon": capa, "fanart": fundo})
        info = {"title": titulo, "tvshowtitle": titulo, "plot": sinopse, "mediatype": "tvshow"}
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        item.setInfo("video", info)

        url = get_url(action="listar_temporadas", s_idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_temporadas(s_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo_serie = serie.get("titulo", "Série")
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa") or ICON_PADRAO
    fundo = serie.get("fundo") or FANART_PADRAO
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo_serie)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else 0):
        qtd_eps = len(temporadas[temp_num])
        label = "[B][COLOR FFB565FF]Temporada {0}[/COLOR][/B]  [COLOR FF90A4AE]({1} episódios)[/COLOR]".format(temp_num, qtd_eps)
        item = xbmcgui.ListItem(label=label)
        item.setArt({"poster": capa, "thumb": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": "Temporada {0}".format(temp_num),
            "tvshowtitle": titulo_serie,
            "plot": sinopse,
            "mediatype": "season"
        })
        url = get_url(action="listar_episodios", s_idx=s_idx, temp=str(temp_num))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(s_idx, temp):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo_serie = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa") or ICON_PADRAO
    fundo = serie.get("fundo") or FANART_PADRAO
    episodios = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, "{0} - T{1}".format(titulo_serie, temp))
    xbmcplugin.setContent(HANDLE, "episodes")

    for e_idx, ep in enumerate(episodios):
        ep_num = ep.get("episodio", e_idx + 1)
        ep_titulo = ep.get("titulo", "Episódio {0}".format(ep_num))
        ep_sinopse = ep.get("sinopse") or serie.get("sinopse", "")
        ep_capa = ep.get("capa") or capa

        try:
            num_fmt = "{0:02d}x{1:02d}".format(int(temp), int(ep_num))
        except Exception:
            num_fmt = "{0}x{1}".format(temp, ep_num)

        label = "[B][COLOR FF00E5FF]{0}[/COLOR][/B] - {1}".format(num_fmt, ep_titulo)
        item = xbmcgui.ListItem(label=label)
        item.setArt({"poster": ep_capa, "thumb": ep_capa, "icon": ep_capa, "fanart": fundo})
        info = {
            "title": ep_titulo,
            "tvshowtitle": titulo_serie,
            "plot": ep_sinopse,
            "mediatype": "episode"
        }
        try:
            info["season"] = int(temp)
            info["episode"] = int(ep_num)
        except Exception:
            pass
        item.setInfo("video", info)

        opcoes = ep.get("opcoes", [])
        magnet_unico = ep.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_episodio", s_idx=s_idx, temp=str(temp), e_idx=e_idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        elif magnet_unico:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                magnet=magnet_unico,
                titulo=ep_titulo,
                tvshowtitle=titulo_serie,
                season=str(temp),
                episode=str(ep_num),
                ano=str(ano),
                sinopse=ep_sinopse,
                capa=ep_capa,
                fundo=fundo,
                mediatype="episode"
            )
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def opcoes_episodio(s_idx, temp, e_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo_serie = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa") or ICON_PADRAO
    fundo = serie.get("fundo") or FANART_PADRAO
    episodios = serie.get("temporadas", {}).get(str(temp), [])
    if e_idx < 0 or e_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[e_idx]
    ep_num = ep.get("episodio", e_idx + 1)
    ep_titulo = ep.get("titulo", "Episódio {0}".format(ep_num))
    ep_sinopse = ep.get("sinopse") or serie.get("sinopse", "")
    ep_capa = ep.get("capa") or capa

    xbmcplugin.setPluginCategory(HANDLE, ep_titulo)
    xbmcplugin.setContent(HANDLE, "episodes")

    for op in ep.get("opcoes", []):
        qualidade = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        if not magnet:
            continue

        selo = formatar_selo_qualidade(qualidade)
        label = "{0}  -  {1}".format(ep_titulo, selo)
        item = xbmcgui.ListItem(label=label)
        item.setArt({"poster": ep_capa, "thumb": ep_capa, "icon": ep_capa, "fanart": fundo})
        item.setInfo("video", {
            "title": ep_titulo,
            "tvshowtitle": titulo_serie,
            "plot": ep_sinopse,
            "mediatype": "episode"
        })
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            magnet=magnet,
            titulo=ep_titulo,
            tvshowtitle=titulo_serie,
            season=str(temp),
            episode=str(ep_num),
            ano=str(ano),
            sinopse=ep_sinopse,
            capa=ep_capa,
            fundo=fundo,
            mediatype="episode"
        )
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    titulo = params.get("titulo", "Cine Telona")
    tvshowtitle = params.get("tvshowtitle", "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    ano = params.get("ano", "")
    sinopse = params.get("sinopse", "")
    capa = params.get("capa") or ICON_PADRAO
    fundo = params.get("fundo") or FANART_PADRAO
    mediatype = params.get("mediatype", "movie")

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "O add-on Elementum não está instalado no Kodi. Instale o Elementum para reproduzir links torrent."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        play_path = "plugin://plugin.video.elementum/play?uri={0}".format(urllib.parse.quote(magnet))
    else:
        play_path = magnet

    item = xbmcgui.ListItem(path=play_path)
    item.setArt({"poster": capa, "thumb": capa, "icon": capa, "fanart": fundo})
    info = {"title": titulo, "plot": sinopse, "mediatype": mediatype}
    if tvshowtitle:
        info["tvshowtitle"] = tvshowtitle
    if season.isdigit():
        info["season"] = int(season)
    if episode.isdigit():
        info["episode"] = int(episode)
    if ano.isdigit():
        info["year"] = int(ano)
    item.setInfo("video", info)

    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action", "")

    if action == "listar_filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        opcoes_filme(int(params.get("idx", 0)))
    elif action == "listar_series":
        listar_series()
    elif action == "listar_temporadas":
        listar_temporadas(int(params.get("s_idx", 0)))
    elif action == "listar_episodios":
        listar_episodios(int(params.get("s_idx", 0)), params.get("temp", "1"))
    elif action == "opcoes_episodio":
        opcoes_episodio(
            int(params.get("s_idx", 0)),
            params.get("temp", "1"),
            int(params.get("e_idx", 0))
        )
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
