import json
import os
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
URL_CATALOGO = "https://nogueira01.github.io/cinetelona/catalogo.json"

ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_FILE = os.path.join(PROFILE_PATH, "catalogo_cache.json")
LOCAL_FILE = os.path.join(ADDON_PATH, "catalogo.json")


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    if not os.path.exists(PROFILE_PATH):
        os.makedirs(PROFILE_PATH, exist_ok=True)

    try:
        req = urllib.request.Request(
            URL_CATALOGO,
            headers={"User-Agent": "Mozilla/5.0 (Kodi CineTelona)"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8-sig")
            dados = json.loads(raw)
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(dados, f, ensure_ascii=False, indent=2)
            return dados
    except Exception as e:
        xbmc.log(f"[CineTelona] Erro ao buscar catalogo remoto: {e}", xbmc.LOGWARNING)

    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    if os.path.exists(LOCAL_FILE):
        try:
            with open(LOCAL_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    return {"filmes": [], "series": []}


def criar_listitem(titulo, sinopse="", ano=None, capa="", fundo="", mediatype="video", is_playable=False):
    item = xbmcgui.ListItem(label=titulo)
    info = {"title": titulo, "plot": sinopse, "mediatype": mediatype}
    if ano:
        try:
            info["year"] = int(ano)
        except Exception:
            pass
    item.setInfo("video", info)

    art = {}
    if capa:
        art["thumb"] = capa
        art["poster"] = capa
        art["icon"] = capa
    if fundo:
        art["fanart"] = fundo
    if art:
        item.setArt(art)

    if is_playable:
        item.setProperty("IsPlayable", "true")
    return item


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    item_filmes = xbmcgui.ListItem(label="Filmes")
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=get_url(action="listar_filmes"),
        listitem=item_filmes,
        isFolder=True,
    )

    item_series = xbmcgui.ListItem(label="Séries")
    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=get_url(action="listar_series"),
        listitem=item_series,
        isFolder=True,
    )

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")
    dados = carregar_catalogo()
    filmes = dados.get("filmes", [])

    for f in filmes:
        titulo = f.get("titulo", "Sem título")
        ano = f.get("ano")
        label = f"{titulo} ({ano})" if ano else titulo
        item = criar_listitem(
            titulo=label,
            sinopse=f.get("sinopse", ""),
            ano=ano,
            capa=f.get("capa", ""),
            fundo=f.get("fundo", ""),
            mediatype="movie",
            is_playable=True,
        )
        link = f.get("magnet", "")
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=get_url(action="play", link=link),
            listitem=item,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")
    dados = carregar_catalogo()
    series = dados.get("series", [])

    for idx, s in enumerate(series):
        titulo = s.get("titulo", "Sem título")
        ano = s.get("ano")
        label = f"{titulo} ({ano})" if ano else titulo
        item = criar_listitem(
            titulo=label,
            sinopse=s.get("sinopse", ""),
            ano=ano,
            capa=s.get("capa", ""),
            fundo=s.get("fundo", ""),
            mediatype="tvshow",
            is_playable=False,
        )
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=get_url(action="listar_temporadas", serie_idx=idx),
            listitem=item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)


def listar_temporadas(serie_idx):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if serie_idx < 0 or serie_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[serie_idx]
    titulo_serie = serie.get("titulo", "Série")
    xbmcplugin.setPluginCategory(HANDLE, titulo_serie)
    xbmcplugin.setContent(HANDLE, "seasons")

    temporadas = serie.get("temporadas", {})
    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else str(x)):
        item = criar_listitem(
            titulo=f"Temporada {temp_num}",
            sinopse=serie.get("sinopse", ""),
            capa=serie.get("capa", ""),
            fundo=serie.get("fundo", ""),
            mediatype="season",
            is_playable=False,
        )
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=get_url(action="listar_episodios", serie_idx=serie_idx, temporada=str(temp_num)),
            listitem=item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(serie_idx, temporada):
    dados = carregar_catalogo()
    series = dados.get("series", [])
    if serie_idx < 0 or serie_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[serie_idx]
    episodios = serie.get("temporadas", {}).get(str(temporada), [])
    xbmcplugin.setPluginCategory(HANDLE, f"{serie.get('titulo', 'Série')} - T{temporada}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for ep in episodios:
        num = ep.get("episodio", "")
        titulo_ep = ep.get("titulo", f"Episódio {num}")
        label = f"{temporada}x{int(num):02d} - {titulo_ep}" if str(num).isdigit() else titulo_ep
        item = criar_listitem(
            titulo=label,
            sinopse=ep.get("sinopse", ""),
            capa=serie.get("capa", ""),
            fundo=serie.get("fundo", ""),
            mediatype="episode",
            is_playable=True,
        )
        link = ep.get("magnet", "")
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=get_url(action="play", link=link),
            listitem=item,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(link):
    if not link:
        xbmcgui.Dialog().notification("Cine Telona", "Link não informado no catálogo.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if link.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "Para reproduzir torrents (links magnet), instale o add-on Elementum no seu Kodi.",
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote_plus(link)}"
    else:
        play_path = link

    item = xbmcgui.ListItem(path=play_path)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "listar_filmes":
        listar_filmes()
    elif action == "listar_series":
        listar_series()
    elif action == "listar_temporadas":
        listar_temporadas(int(params.get("serie_idx", -1)))
    elif action == "listar_episodios":
        listar_episodios(int(params.get("serie_idx", -1)), params.get("temporada", "1"))
    elif action == "play":
        reproduzir(params.get("link", ""))
    else:
        menu_principal()


if __name__ == "__main__":
    param = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(param)
