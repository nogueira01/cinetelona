import sys
import os
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")

URL_CATALOGO = "https://nogueira01.github.io/cinetelona/catalogo.json"

ICON_DEFAULT = os.path.join(ADDON_PATH, "icon.png")
FANART_DEFAULT = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    try:
        req = urllib.request.Request(
            URL_CATALOGO,
            headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"}
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            dados = json.loads(resp.read().decode("utf-8"))
            if isinstance(dados, dict) and ("filmes" in dados or "series" in dados):
                return dados
    except Exception:
        pass

    local_path = os.path.join(ADDON_PATH, "catalogo.json")
    try:
        with open(local_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"filmes": [], "series": []}


def aplicar_painel_grande():
    skin = xbmc.getSkinDir()
    if "estuary" in skin.lower():
        xbmc.executebuiltin("Container.SetViewMode(51)")
    else:
        xbmc.executebuiltin("Container.SetViewMode(500)")


def formatar_qualidade(qualidade):
    q_low = qualidade.lower()
    if "4k" in q_low or "2160" in q_low:
        return f"[COLOR FFFFD700]★ {qualidade}[/COLOR]"
    elif "full" in q_low:
        return f"[COLOR FFB565FF]◆ {qualidade}[/COLOR]"
    return f"[COLOR FF00E5FF]● {qualidade}[/COLOR]"


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    catalogo = carregar_catalogo()
    qtd_filmes = len(catalogo.get("filmes", []))
    qtd_series = len(catalogo.get("series", []))

    item_filmes = xbmcgui.ListItem(
        label=f"[B][COLOR FF00E5FF]FILMES[/COLOR][/B]  [COLOR FFAAAAAA]({qtd_filmes})[/COLOR]"
    )
    item_filmes.setArt({"icon": ICON_FILMES, "thumb": ICON_FILMES, "poster": ICON_FILMES, "fanart": FANART_DEFAULT})
    item_filmes.setInfo("video", {"title": "Filmes", "plot": "Catálogo completo de filmes em alta definição."})
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action="filmes"), item_filmes, isFolder=True)

    item_series = xbmcgui.ListItem(
        label=f"[B][COLOR FFB565FF]SÉRIES[/COLOR][/B]  [COLOR FFAAAAAA]({qtd_series})[/COLOR]"
    )
    item_series.setArt({"icon": ICON_SERIES, "thumb": ICON_SERIES, "poster": ICON_SERIES, "fanart": FANART_DEFAULT})
    item_series.setInfo("video", {"title": "Séries", "plot": "Séries organizadas por temporadas e episódios."})
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action="series"), item_series, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")

    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])

    for idx, filme in enumerate(filmes):
        titulo = filme.get("titulo", "Sem Título")
        ano = filme.get("ano", 0)
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa") or ICON_FILMES
        fundo = filme.get("fundo") or FANART_DEFAULT

        label = f"{titulo} ({ano})" if ano else titulo
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": titulo,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": sinopse,
            "mediatype": "movie"
        })

        opcoes = filme.get("opcoes", [])
        magnet_direto = filme.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
        elif magnet_direto:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                link=magnet_direto,
                titulo=titulo,
                ano=str(ano),
                sinopse=sinopse,
                capa=capa,
                fundo=fundo,
                tipo="movie"
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_opcoes_filme(idx):
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", 0)
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_FILMES
    fundo = filme.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for op in filme.get("opcoes", []):
        qualidade = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        if not magnet:
            continue

        label = f"{titulo} - {formatar_qualidade(qualidade)}"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": titulo,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": sinopse,
            "mediatype": "movie"
        })
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            link=magnet,
            titulo=titulo,
            ano=str(ano),
            sinopse=sinopse,
            capa=capa,
            fundo=fundo,
            tipo="movie"
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")

    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])

    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", "Sem Título")
        ano = serie.get("ano", 0)
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa") or ICON_SERIES
        fundo = serie.get("fundo") or FANART_DEFAULT

        label = f"{titulo} ({ano})" if ano else titulo
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": titulo,
            "tvshowtitle": titulo,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": sinopse,
            "mediatype": "tvshow"
        })

        url = get_url(action="temporadas", idx=idx)
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_painel_grande()


def listar_temporadas(idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else 999):
        label = f"[COLOR FF00E5FF]Temporada {temp_num}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": f"Temporada {temp_num}",
            "tvshowtitle": titulo,
            "season": int(temp_num) if str(temp_num).isdigit() else 1,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": sinopse,
            "mediatype": "season"
        })
        url = get_url(action="episodios", idx=idx, temp=str(temp_num))
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(idx, temp):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    episodios = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{serie_titulo} - Temporada {temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for ep_idx, ep in enumerate(episodios):
        ep_num = ep.get("episodio", ep_idx + 1)
        ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
        ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))

        prefixo = f"[COLOR FFB565FF]{int(temp):02d}x{int(ep_num):02d}[/COLOR]" if str(temp).isdigit() and str(ep_num).isdigit() else f"{temp}x{ep_num}"
        label = f"{prefixo} - {ep_titulo}"

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "season": int(temp) if str(temp).isdigit() else 1,
            "episode": int(ep_num) if str(ep_num).isdigit() else 1,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": ep_sinopse,
            "mediatype": "episode"
        })

        opcoes = ep.get("opcoes", [])
        magnet_direto = ep.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_ep", idx=idx, temp=str(temp), ep_idx=ep_idx)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
        elif magnet_direto:
            item.setProperty("IsPlayable", "true")
            url = get_url(
                action="play",
                link=magnet_direto,
                titulo=ep_titulo,
                serie=serie_titulo,
                temp=str(temp),
                ep=str(ep_num),
                ano=str(ano),
                sinopse=ep_sinopse,
                capa=capa,
                fundo=fundo,
                tipo="episode"
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_ep(idx, temp, ep_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if idx < 0 or idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    episodios = serie.get("temporadas", {}).get(str(temp), [])
    if ep_idx < 0 or ep_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[ep_idx]
    ep_num = ep.get("episodio", ep_idx + 1)
    ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
    ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))

    xbmcplugin.setPluginCategory(HANDLE, ep_titulo)
    xbmcplugin.setContent(HANDLE, "episodes")

    for op in ep.get("opcoes", []):
        qualidade = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        if not magnet:
            continue

        label = f"{ep_titulo} - {formatar_qualidade(qualidade)}"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})
        item.setInfo("video", {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "season": int(temp) if str(temp).isdigit() else 1,
            "episode": int(ep_num) if str(ep_num).isdigit() else 1,
            "year": int(ano) if str(ano).isdigit() else 0,
            "plot": ep_sinopse,
            "mediatype": "episode"
        })
        item.setProperty("IsPlayable", "true")

        url = get_url(
            action="play",
            link=magnet,
            titulo=ep_titulo,
            serie=serie_titulo,
            temp=str(temp),
            ep=str(ep_num),
            ano=str(ano),
            sinopse=ep_sinopse,
            capa=capa,
            fundo=fundo,
            tipo="episode"
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    link = params.get("link", "")
    titulo = params.get("titulo", "Vídeo")
    serie = params.get("serie", "")
    temp = params.get("temp", "")
    ep = params.get("ep", "")
    ano = params.get("ano", "0")
    sinopse = params.get("sinopse", "")
    capa = params.get("capa", ICON_DEFAULT)
    fundo = params.get("fundo", FANART_DEFAULT)
    tipo = params.get("tipo", "movie")

    if link.startswith("magnet:"):
        encoded = urllib.parse.quote_plus(link)
        play_path = f"plugin://plugin.video.elementum/play?uri={encoded}"
    else:
        play_path = link

    item = xbmcgui.ListItem(path=play_path)
    item.setArt({"icon": capa, "thumb": capa, "poster": capa, "fanart": fundo})

    info = {
        "title": titulo,
        "year": int(ano) if str(ano).isdigit() else 0,
        "plot": sinopse,
        "mediatype": tipo
    }
    if tipo == "episode":
        info["tvshowtitle"] = serie
        if str(temp).isdigit():
            info["season"] = int(temp)
        if str(ep).isdigit():
            info["episode"] = int(ep)

    item.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=item)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action == "filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", -1)))
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("idx", -1)), params.get("temp", "1"))
    elif action == "opcoes_ep":
        listar_opcoes_ep(int(params.get("idx", -1)), params.get("temp", "1"), int(params.get("ep_idx", 0)))
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[1].lstrip("?") if len(sys.argv) > 1 else "")
