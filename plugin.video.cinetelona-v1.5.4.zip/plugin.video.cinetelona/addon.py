import os
import sys
import json
import urllib.parse
import urllib.request
import ssl
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

URL_CATALOGO = "https://nogueira01.github.io/cinetelona/catalogo.json"
ICON_PADRAO = os.path.join(ADDON_PATH, "icon.png")
FANART_PADRAO = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")


def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)


def carregar_catalogo():
    cache_path = os.path.join(ADDON_PATH, "catalogo_cache.json")
    local_path = os.path.join(ADDON_PATH, "catalogo.json")
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            URL_CATALOGO,
            headers={"User-Agent": "Mozilla/5.0 (Kodi Addon CineTelona)"}
        )
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            raw = resp.read().decode("utf-8-sig")
            data = json.loads(raw)
            if isinstance(data, dict) and ("filmes" in data or "series" in data):
                try:
                    with open(cache_path, "w", encoding="utf-8") as cf:
                        cf.write(raw)
                except Exception:
                    pass
                return data
    except Exception as e:
        xbmc.log(f"[CineTelona] Falha ao baixar catalogo remoto: {e}", xbmc.LOGWARNING)

    for fallback in (cache_path, local_path):
        if os.path.exists(fallback):
            try:
                with open(fallback, "r", encoding="utf-8-sig") as f:
                    return json.load(f)
            except Exception:
                pass
    return {"filmes": [], "series": []}


def aplicar_arte(item, capa="", fundo=""):
    poster = capa if capa else ICON_PADRAO
    fanart = fundo if fundo else FANART_PADRAO
    item.setArt({
        "thumb": poster,
        "icon": poster,
        "poster": poster,
        "fanart": fanart
    })


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    catalogo = carregar_catalogo()
    qtd_filmes = len(catalogo.get("filmes", []))
    qtd_series = len(catalogo.get("series", []))

    itens = [
        (
            f"[COLOR FF00E5FF][B]FILMES[/B][/COLOR] [COLOR FFAAAAAA]({qtd_filmes})[/COLOR]",
            {"action": "filmes"},
            ICON_FILMES,
            "Catálogo completo de filmes em alta definição."
        ),
        (
            f"[COLOR FFB565FF][B]SÉRIES[/B][/COLOR] [COLOR FFAAAAAA]({qtd_series})[/COLOR]",
            {"action": "series"},
            ICON_SERIES,
            "Séries organizadas por temporadas e episódios."
        )
    ]

    for label, params, icone, sinopse in itens:
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, icone, FANART_PADRAO)
        li.setInfo("video", {"title": label, "plot": sinopse})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes():
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")

    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])

    for idx, filme in enumerate(filmes):
        titulo = filme.get("titulo", f"Filme {idx + 1}")
        ano = filme.get("ano", 0)
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa", "")
        fundo = filme.get("fundo", "")

        label = f"{titulo} ({ano})" if ano else titulo
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, capa, fundo)

        info = {
            "title": titulo,
            "originaltitle": titulo,
            "plot": sinopse,
            "mediatype": "movie"
        }
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        li.setInfo("video", info)

        opcoes = filme.get("opcoes", [])
        magnet_unico = filme.get("magnet", "")

        if opcoes:
            url = build_url({"action": "opcoes_filme", "idx": idx})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
        elif magnet_unico:
            li.setProperty("IsPlayable", "true")
            url = build_url({
                "action": "play",
                "magnet": magnet_unico,
                "titulo": titulo,
                "ano": str(ano),
                "sinopse": sinopse,
                "capa": capa,
                "fundo": fundo,
                "tipo": "movie"
            })
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    try:
        xbmc.executebuiltin("Container.SetViewMode(51)")
    except Exception:
        pass


def listar_opcoes_filme(idx):
    catalogo = carregar_catalogo()
    filmes = catalogo.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", 0)
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa", "")
    fundo = filme.get("fundo", "")
    opcoes = filme.get("opcoes", [])

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for op in opcoes:
        qualidade = op.get("qualidade", "HD")
        magnet = op.get("magnet", "").strip()
        if not magnet:
            continue

        q_lower = qualidade.lower()
        if "4k" in q_lower or "2160" in q_lower:
            badge = f"[COLOR FFFFD700][B]★ {qualidade}[/B][/COLOR]"
        elif "full" in q_lower:
            badge = f"[COLOR FFB565FF][B]◆ {qualidade}[/B][/COLOR]"
        else:
            badge = f"[COLOR FF00E5FF][B]● {qualidade}[/B][/COLOR]"

        label = f"{titulo} - {badge}"
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, capa, fundo)
        info = {
            "title": f"{titulo} ({qualidade})",
            "plot": sinopse,
            "mediatype": "movie"
        }
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")

        url = build_url({
            "action": "play",
            "magnet": magnet,
            "titulo": titulo,
            "ano": str(ano),
            "sinopse": sinopse,
            "capa": capa,
            "fundo": fundo,
            "tipo": "movie"
        })
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series():
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")

    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])

    for idx, serie in enumerate(series):
        titulo = serie.get("titulo", f"Série {idx + 1}")
        ano = serie.get("ano", 0)
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa", "")
        fundo = serie.get("fundo", "")

        label = f"{titulo} ({ano})" if ano else titulo
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, capa, fundo)
        info = {
            "title": titulo,
            "tvshowtitle": titulo,
            "plot": sinopse,
            "mediatype": "tvshow"
        }
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        li.setInfo("video", info)

        url = build_url({"action": "temporadas", "s_idx": idx})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    try:
        xbmc.executebuiltin("Container.SetViewMode(51)")
    except Exception:
        pass


def listar_temporadas(s_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo = serie.get("titulo", "Série")
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa", "")
    fundo = serie.get("fundo", "")
    temporadas = serie.get("temporadas", {})

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp_num in sorted(temporadas.keys(), key=lambda x: int(x) if str(x).isdigit() else 999):
        qtd_eps = len(temporadas[temp_num])
        label = f"Temporada {temp_num} ({qtd_eps} episódios)"
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, capa, fundo)
        li.setInfo("video", {
            "title": label,
            "tvshowtitle": titulo,
            "plot": sinopse,
            "season": int(temp_num) if str(temp_num).isdigit() else 1,
            "mediatype": "season"
        })
        url = build_url({"action": "episodios", "s_idx": s_idx, "temp": str(temp_num)})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(s_idx, temp):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    capa = serie.get("capa", "")
    fundo = serie.get("fundo", "")
    episodios = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{serie_titulo} - Temporada {temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    for e_idx, ep in enumerate(episodios):
        ep_num = ep.get("episodio", e_idx + 1)
        ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
        ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))
        ep_capa = ep.get("capa", capa)
        ep_fundo = ep.get("fundo", fundo)

        try:
            s_num_int = int(temp)
        except Exception:
            s_num_int = 1
        try:
            e_num_int = int(ep_num)
        except Exception:
            e_num_int = e_idx + 1

        label = f"[COLOR FF00E5FF]{s_num_int:02d}x{e_num_int:02d}[/COLOR] - {ep_titulo}"
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, ep_capa, ep_fundo)
        info = {
            "title": ep_titulo,
            "tvshowtitle": serie_titulo,
            "season": s_num_int,
            "episode": e_num_int,
            "plot": ep_sinopse,
            "mediatype": "episode"
        }
        if ano:
            try:
                info["year"] = int(ano)
            except Exception:
                pass
        li.setInfo("video", info)

        opcoes = ep.get("opcoes", [])
        magnet_unico = ep.get("magnet", "").strip()

        if opcoes:
            url = build_url({
                "action": "opcoes_ep",
                "s_idx": s_idx,
                "temp": str(temp),
                "e_idx": e_idx
            })
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
        elif magnet_unico:
            li.setProperty("IsPlayable", "true")
            url = build_url({
                "action": "play",
                "magnet": magnet_unico,
                "titulo": ep_titulo,
                "serie": serie_titulo,
                "season": str(s_num_int),
                "episode": str(e_num_int),
                "ano": str(ano),
                "sinopse": ep_sinopse,
                "capa": ep_capa,
                "fundo": ep_fundo,
                "tipo": "episode"
            })
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_episodio(s_idx, temp, e_idx):
    catalogo = carregar_catalogo()
    series = catalogo.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    serie_titulo = serie.get("titulo", "Série")
    ano = serie.get("ano", 0)
    episodios = serie.get("temporadas", {}).get(str(temp), [])
    if e_idx < 0 or e_idx >= len(episodios):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep = episodios[e_idx]
    ep_num = ep.get("episodio", e_idx + 1)
    ep_titulo = ep.get("titulo", f"Episódio {ep_num}")
    ep_sinopse = ep.get("sinopse", serie.get("sinopse", ""))
    ep_capa = ep.get("capa", serie.get("capa", ""))
    ep_fundo = ep.get("fundo", serie.get("fundo", ""))
    opcoes = ep.get("opcoes", [])

    xbmcplugin.setPluginCategory(HANDLE, ep_titulo)
    xbmcplugin.setContent(HANDLE, "episodes")

    for op in opcoes:
        qualidade = op.get("qualidade", "HD")
        magnet = op.get("magnet", "").strip()
        if not magnet:
            continue

        q_lower = qualidade.lower()
        if "4k" in q_lower or "2160" in q_lower:
            badge = f"[COLOR FFFFD700][B]★ {qualidade}[/B][/COLOR]"
        elif "full" in q_lower:
            badge = f"[COLOR FFB565FF][B]◆ {qualidade}[/B][/COLOR]"
        else:
            badge = f"[COLOR FF00E5FF][B]● {qualidade}[/B][/COLOR]"

        label = f"{ep_titulo} - {badge}"
        li = xbmcgui.ListItem(label=label)
        aplicar_arte(li, ep_capa, ep_fundo)
        li.setInfo("video", {
            "title": f"{ep_titulo} ({qualidade})",
            "tvshowtitle": serie_titulo,
            "season": int(temp) if str(temp).isdigit() else 1,
            "episode": int(ep_num) if str(ep_num).isdigit() else 1,
            "plot": ep_sinopse,
            "mediatype": "episode"
        })
        li.setProperty("IsPlayable", "true")

        url = build_url({
            "action": "play",
            "magnet": magnet,
            "titulo": ep_titulo,
            "serie": serie_titulo,
            "season": str(temp),
            "episode": str(ep_num),
            "ano": str(ano),
            "sinopse": ep_sinopse,
            "capa": ep_capa,
            "fundo": ep_fundo,
            "tipo": "episode"
        })
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "").strip()
    titulo = params.get("titulo", "Cine Telona")
    serie = params.get("serie", "")
    sinopse = params.get("sinopse", "")
    capa = params.get("capa", "")
    fundo = params.get("fundo", "")
    tipo = params.get("tipo", "movie")
    ano = params.get("ano", "")
    season = params.get("season", "")
    episode = params.get("episode", "")

    if not magnet:
        xbmcgui.Dialog().notification("Cine Telona", "Link de vídeo vazio.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "Cine Telona",
                "O add-on Elementum não está instalado ou está desativado. Instale o Elementum para reproduzir links torrent."
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        play_path = "plugin://plugin.video.elementum/play?uri=" + urllib.parse.quote(magnet, safe="")
    else:
        play_path = magnet

    li = xbmcgui.ListItem(label=titulo, path=play_path)
    aplicar_arte(li, capa, fundo)

    info = {
        "title": titulo,
        "plot": sinopse,
        "mediatype": tipo
    }
    if ano and str(ano).isdigit() and int(ano) > 0:
        info["year"] = int(ano)
    if tipo == "episode":
        if serie:
            info["tvshowtitle"] = serie
        if season and str(season).isdigit():
            info["season"] = int(season)
        if episode and str(episode).isdigit():
            info["episode"] = int(episode)

    li.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)


def router():
    param_str = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(param_str))
    action = params.get("action", "")

    if action == "filmes":
        listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", -1)))
    elif action == "series":
        listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("s_idx", -1)))
    elif action == "episodios":
        listar_episodios(int(params.get("s_idx", -1)), params.get("temp", "1"))
    elif action == "opcoes_ep":
        listar_opcoes_episodio(
            int(params.get("s_idx", -1)),
            params.get("temp", "1"),
            int(params.get("e_idx", -1))
        )
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router()
